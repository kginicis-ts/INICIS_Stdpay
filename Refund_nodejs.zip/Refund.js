const express = require("express"); 
const Refund = express();
const crypto = require('crypto'); 
const bodyParser = require("body-parser");
const request = require('request');


Refund.use(bodyParser.json());
Refund.use(bodyParser.urlencoded({extended : true}));

Date.prototype.YYYYMMDDHHMMSS = function () {
    var yyyy = this.getFullYear().toString();
    var MM = pad(this.getMonth() + 1,2);
    var dd = pad(this.getDate(), 2);
    var hh = pad(this.getHours(), 2);
    var mm = pad(this.getMinutes(), 2)
    var ss = pad(this.getSeconds(), 2)
  
    return yyyy +  MM + dd+  hh + mm + ss;
};
  
function pad(number, length) {
    var str = '' + number;
    while (str.length < length) {
      str = '0' + str;
    }
    return str;
}
      
var nowDate = new Date();
var HashMap = require ('hashmap');
    

//step1. 요청을 위한 파라미터 설정
const key = "";    
const type = "Refund";
const paymethod = "CARD";
const timestamp = nowDate.YYYYMMDDHHMMSS();
const clientIp = "111.222.333.889";
const mid = "";	
const tid = "";
const msg = "취소요청";

// Hash Encryption
const data_hash = key + type + paymethod + timestamp + clientIp + mid + tid;
const hashData = crypto.createHash('sha512').update(data_hash).digest('hex');

const apiUrl = "https://iniapi.inicis.com/api/v1/refund"


let options = {
    type : type,
    paymethod : paymethod,
    timestamp : timestamp,
    clientIp : clientIp,
    mid : mid,
    tid : tid,
    msg : msg,
    hashData : hashData
}


request.post({method: 'POST', uri: apiUrl, form: options}, (err,httpResponse,body) =>{ 
    console.log(body)
});

