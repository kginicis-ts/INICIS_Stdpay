const express = require("express"); 
const vPartialRefund = express();
const crypto = require('crypto'); 
const bodyParser = require("body-parser");
const request = require('request');


vPartialRefund.use(bodyParser.json());
vPartialRefund.use(bodyParser.urlencoded({extended : true}));

Date.prototype.YYYYMMDDHHMMSS = function () {
    var yyyy = this.getFullYear().toString();
    var MM = pad(this.getMonth() + 1,2);
    var dd = pad(this.getDate(), 2);
    var hh = pad(this.getHours(), 2);
    var mm = pad(this.getMinutes(), 2)
    var ss = pad(this.getSeconds(), 2)
  
    return yyyy +  MM + dd+  hh + mm + ss;
};
  
function pad(number, length) {
    var str = '' + number;
    while (str.length < length) {
      str = '0' + str;
    }
    return str;
}
var nowDate = new Date();


function AES_encrypt(str, apikey, ivKey) {
    const cipher = crypto.createCipheriv('aes-128-cbc', apikey, ivKey);
    let encryptedText = cipher.update(str, 'utf8', 'base64');
    encryptedText += cipher.final('base64');
    return encryptedText;
}
    

//step1. 요청을 위한 파라미터 설정
const key = ""; 
const iv = "==";		
const type = "PartialRefund";
const paymethod = "Vacct";
const timestamp = nowDate.YYYYMMDDHHMMSS();
const clientIp = "111.222.333.889";
const mid = "";	
const tid = "";
const msg = "가상계좌 부분환불요청";
const price = "";												
const confirmPrice = "";
const refundAcctNum = "";									
const refundBankCode = "";									
const refundAcctName = "";	

// AES Encryption
let enc_refundAcctNum = AES_encrypt(refundAcctNum, key, iv);

// Hash Encryption
const data_hash = key + type + paymethod + timestamp + clientIp + mid + tid + price + confirmPrice + enc_refundAcctNum;
const hashData = crypto.createHash('sha512').update(data_hash).digest('hex');

const apiUrl = "https://iniapi.inicis.com/api/v1/refund"


let options = {
    type : type,
    paymethod : paymethod,
    timestamp : timestamp,
    clientIp : clientIp,
    mid : mid,
    tid : tid,
    msg : msg,
    price : price,
    confirmPrice :confirmPrice,
    refundAcctNum : enc_refundAcctNum,
    refundBankCode : refundBankCode,
    refundAcctName : refundAcctName,
    hashData : hashData
}


request.post({method: 'POST', uri: apiUrl, form: options}, (err,httpResponse,body) =>{ 
    console.log(body)
});
