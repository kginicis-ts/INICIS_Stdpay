const express = require("express"); 
const app = express();
const crypto = require('crypto'); 
const bodyParser = require("body-parser");
const request = require('request');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));

app.set("views" , __dirname+"/views");
app.set("views engline" , "ejs");
app.engine("html", require("ejs").renderFile);

app.use(express.static("views"));  

var HashMap = require ('hashmap');

Date.prototype.YYYYMMDDHHMMSS = function () {
    var yyyy = this.getFullYear().toString();
    var MM = pad(this.getMonth() + 1,2);
    var dd = pad(this.getDate(), 2);
    var hh = pad(this.getHours(), 2);
    var mm = pad(this.getMinutes(), 2)
    var ss = pad(this.getSeconds(), 2)
  
    return yyyy +  MM + dd+  hh + mm + ss;
  };
  
  function pad(number, length) {
    var str = '' + number;
    while (str.length < length) {
      str = '0' + str;
    }
    return str;
  }
      
  var nowDate = new Date();


app.get("/" , (req,res) =>{
    const mid = "INIBillTst"; // 상점아이디
    const INILitekey = "b09LVzhuTGZVaEY1WmJoQnZzdXpRdz09";  //inilite키
    const timestamp = nowDate.YYYYMMDDHHMMSS();  // 전문생성시간 [YYYYMMDDhhmmss]
    const orderid = mid + "_" + timestamp; // 주문번호
    const price = "1000"; // 결제금액 
    const hashdata  = crypto.createHash("sha256").update(mid+orderid+timestamp+INILitekey).digest('hex'); //SHA256 Hash값 [대상: mid, orderid, timestamp, INILitekey]
    
    res.render("INIbill_mo_req.html" , {
        mid : mid,
        orderid : orderid,
        price : price,
        timestamp : timestamp,
        hashdata : hashdata
    });
});

app.post("/INIbill_mo_return.ejs" , (req , res) => {


    if(req.body.resultCode == "00"){
       //인증 결과 
        const resultCode = req.body.resultCode; // 결과코드
        const resultmsg = req.body.resultmsg; // 결과메시지
        const tid = req.body.tid; // 거래번호
        const billkey = req.body.billkey; // 발급된 빌링키
        const orderid = req.body.orderid; // 주문번호 (빌키발급 요청 시 세팅한 값)
        const pgauthdate = req.body.pgauthdate; // 거래일자 [YYYYMMDD]
        const pgauthtime = req.body.pgauthtime; // 거래시간 [hhmmss]

        
        
        res.render('INIbill_mo_return.ejs',{
            resultCode : req.body.resultCode,
            resultmsg : req.body.resultmsg,
            tid : req.body.tid,
            billkey : req.body.billkey,
            orderid : req.body.orderid,
            pgauthdate : req.body.pgauthdate,
            pgauthtime : req.body.pgauthtime
           }) 
        

        
    }else{

        res.render('INIbill_mo_return.ejs',{
            resultcode : req.body.resultcode,
            resultmsg : req.body.resultmsg,
            tid : req.body.tid,
            billkey : req.body.billkey,
            orderid : req.body.orderid,
            pgauthdate : req.body.pgauthdate,
            pgauthtime : req.body.pgauthtime
           }) 
    }
});

app.get('/close', (req, res) => {
    res.send('<script language="javascript" type="text/javascript" src="https://stdpay.inicis.com/stdjs/INIStdPay_close.js" charset="UTF-8"></script>');
});


app.listen(3000 , (err) =>{
    if(err) return console.log(err);
    console.log("The server is listening on port 3000");
});