const express = require("express"); 
const app = express();
const crypto = require('crypto'); 
const bodyParser = require("body-parser");
const request = require('request');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));

app.set("views" , __dirname+"/views");
app.set("views engline" , "ejs");
app.engine("html", require("ejs").renderFile);

app.use(express.static("views"));  //추가해야 css 적용됨

var HashMap = require ('hashmap');

app.get("/" , (req,res) =>{
    const P_MID = "INIpayTest"; // 상점아이디
    const P_OID = "mobile_test1234"; // 주문번호
    const P_AMT = "1000"; // 결제금액 * 숫자만, 1달러는 100으로 시작
    
  
    res.render("INImobile_mo_req.html" , {
        P_MID : P_MID,
        P_OID : P_OID,
        P_AMT : P_AMT
    });
});

app.post("/INImobile_mo_return.ejs" , (req , res) => {

    if(req.body.P_STATUS === "00"){
       //인증 결과 
        const P_STATUS = req.body.P_STATUS; // 결과코드
        const P_RMESG1 = req.body.P_RMESG1; // 결과메시지
        const P_TID = req.body.P_TID; // 인증거래번호(성공시에만 전달)
        const P_AMT = req.body.P_AMT; // 거래금액
        const P_REQ_URL = req.body.P_REQ_URL; // 승인요청 URL
        const P_NOTI = req.body.P_NOTI; // 가맹점 임의 데이터


        //결제 승인 요청 
        let options = { 
                P_MID : P_TID.substring(10, 20),
                P_TID : P_TID, 

                
        };
    

        request.post({method: 'POST', uri: P_REQ_URL + "?P_TID=" + P_TID + "&P_MID=" + options.P_MID, form: options}, (err,httpResponse,body) =>{ 
            
            try{
  
                let values = [];
                values = new String(body).split("&"); 
                console.log(values)
                var map = new HashMap();
				for( let x = 0; x < values.length; x++ ) {
						  
					// 승인결과를 파싱값 잘라 hashmap에 저장
					let i = values[x].indexOf("=");
					let key1 = values[x].substring(0, i);
					let value1 = values[x].substring(i+1);
					map.set(key1, value1);
					
				}
            
            
                res.render('INImobile_mo_return.ejs',{
                P_STATUS :  map.get("P_STATUS"),
                P_RMESG1 :  map.get("P_RMESG1"),
                P_TID :  map.get("P_TID"),
                P_TYPE :  map.get("P_TYPE"),
                P_OID :  map.get("P_OID"),
                P_AMT :  map.get("P_AMT"),
                P_AUTH_DT :  map.get("P_AUTH_DT"),
                P_VACT_NUM :  map.get("P_VACT_NUM")
                
               }) 
               

            }catch(e){
                /*
                    가맹점에서 승인결과 전문 처리 중 예외발생 시 망취소 요청할 수 있습니다.
                    승인요청 전문과 동일한 스펙으로 진행되며, 인증결과 수신 시 전달받은 "netCancelUrl" 로 망취소요청합니다.

                    ** 망취소를 일반 결제취소 용도로 사용하지 마십시오.
                    일반 결제취소는 INIAPI 취소/환불 서비스를 통해 진행해주시기 바랍니다.
                */
                console.log(e);
                request.post({method: 'POST', uri: netCancelUrl, form: options, json: true}, (err,httpResponse,body) =>{
                    let result = (err) ? err : JSON.stringify(body);
                  
                    console.log("<p>"+result+"</p>");
                    
                });
            }
        });
    }else{

        res.render('INImobile_mo_return.ejs',{
            P_STATUS : req.body.P_STATUS,
            P_RMESG1 : req.body.P_RMESG1,
           }) 
    }
});

app.get('/close', (req, res) => {
    res.send('<script language="javascript" type="text/javascript" src="https://stdpay.inicis.com/stdjs/INIStdPay_close.js" charset="UTF-8"></script>');
});


app.listen(3000 , (err) =>{
    if(err) return console.log(err);
    console.log("The server is listening on port 3000");
});