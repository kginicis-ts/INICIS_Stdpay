const express = require("express"); 
const app = express();
const crypto = require('crypto'); 
const bodyParser = require("body-parser");
const request = require('request');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));

app.set("views" , __dirname+"/views");
app.set("views engline" , "ejs");
app.engine("html", require("ejs").renderFile);

app.get("/" , (req,res) =>{
    const mid = "INIpayTest"; // 상점아이디
    const signkey = "SU5JTElURV9UUklQTEVERVNfS0VZU1RS";
    const mKey = crypto.createHash("sha256").update(signkey).digest('hex'); // SHA256 Hash값 [대상: mid 와 매칭되는 signkey]
    const oid = "INIpayTest_01234"; // 주문번호
    const price = "1000"; // 결제금액 * 숫자만, 1달러는 100으로 시작
    const timestamp = new Date().getTime(); // 타임스템프 [TimeInMillis(Long형)]
    const signature  = crypto.createHash("sha256").update("oid="+oid+"&price="+price+"&timestamp="+timestamp).digest('hex'); //SHA256 Hash값 [대상: oid, price, timestamp]
  
    res.render("request.html" , {
        mid : mid,
        oid : oid,
        price : price,
        timestamp : timestamp,
        mKey : mKey,
        signature : signature
    });
});

app.post("/return" , (req , res) => {

    if(req.body.resultCode === "0000"){

        const mid = req.body.mid; // 상점아이디
        const authToken = req.body.authToken; // 승인요청 검증 토큰
        const authUrl = req.body.authUrl; // 승인요청 Url
        const netCancelUrl = req.body.netCancelUrl; // 망취소요청 Url * 승인요청 후 승인결과 수신 실패 / DB저장 실패 시
        const timestamp = new Date().getTime(); // 타임스템프 [TimeInMillis(Long형)]
        const charset = "UTF-8"; // 리턴형식[UTF-8,EUC-KR](가맹점 수정후 고정)
        const format = "JSON"; // 리턴형식[XML,JSON,NVP](가맹점 수정후 고정)

        // SHA256 Hash값 [대상: authToken, timestamp]
        const signature  = crypto.createHash("sha256").update("authToken="+authToken+"&timestamp="+timestamp).digest('hex');
    
        //결제 승인 요청 
        let options = { 
                mid : mid,
                authToken : authToken, 
                timestamp : timestamp,
                signature : signature,
                charset : charset,
                format : format
        };

        request.post({method: 'POST', uri: authUrl, form: options, json: true}, (err,httpResponse,body) =>{ 
            
            try{
  
                let result = (err) ? err : JSON.stringify(body);
               
                res.send("<p>"+result+"</p>");

            }catch(e){
                /*
                    가맹점에서 승인결과 전문 처리 중 예외발생 시 망취소 요청할 수 있습니다.
                    승인요청 전문과 동일한 스펙으로 진행되며, 인증결과 수신 시 전달받은 "netCancelUrl" 로 망취소요청합니다.

                    ** 망취소를 일반 결제취소 용도로 사용하지 마십시오.
                    일반 결제취소는 INIAPI 취소/환불 서비스를 통해 진행해주시기 바랍니다.
                */
                console.log(e);
                request.post({method: 'POST', uri: netCancelUrl, form: options, json: true}, (err,httpResponse,body) =>{
                    let result = (err) ? err : JSON.stringify(body);
                  
                    res.send("<p>"+result+"</p>");
                });
            }
        });
    }else{
        console.log(req.body.resultCode);
    }
});

app.get('/close', (req, res) => {
    res.send('<script language="javascript" type="text/javascript" src="https://stdpay.inicis.com/stdjs/INIStdPay_close.js" charset="UTF-8"></script>');
});


app.listen(3000 , (err) =>{
    if(err) return console.log(err);
    console.log("The server is listening on port 3000");
});